#include <DHT.h>

const int BTN = 2;
const int LED = 8;
const int POT = A0;

#define DHTPIN 4
#define DHTTYPE DHT22

DHT dht(DHTPIN, DHTTYPE);

void setup() {
pinMode(BTN, INPUT_PULLUP);
pinMode(LED, OUTPUT);

Serial.begin(9600);

dht.begin();
}

void loop() {
// Leitura do botão
bool pressionado = (digitalRead(BTN) == LOW);

// Controle do LED
if (pressionado) {
digitalWrite(LED, HIGH);
} else {
digitalWrite(LED, LOW);
}

// Leitura do potenciômetro
int bruto = analogRead(POT);

// Leitura da temperatura
float temperatura = dht.readTemperature();

// Exibição do potenciômetro
Serial.print("Potenciometro: ");
Serial.println(bruto);

// Exibição da temperatura
Serial.print("Temperatura: ");

if (isnan(temperatura)) {
Serial.println("INVALIDA");
} else {
Serial.print(temperatura);
Serial.println(" C");
}

// Classificação integrada
if (isnan(temperatura)) {
Serial.println("FALHA DE SENSOR");
}
else if (temperatura >= 40 || bruto >= 750) {
Serial.println("ALARME");
}
else if (temperatura >= 30 || bruto >= 400) {
Serial.println("ATENCAO");
}
else {
Serial.println("NORMAL");
}

// Estado do botão
Serial.print("Botao: ");

if (pressionado) {
Serial.println("PRESSIONADO - LED ON");
} else {
Serial.println("LIVRE - LED OFF");
}

Serial.println("--------------------");

delay(1000);
}